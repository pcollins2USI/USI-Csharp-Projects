﻿

//Programmer:   Patrick Collins
//Date:         (Assignment 3) 09/16/2018 
//Description:  A Professor rating console app 
//Note:         I have added a color change affect to further help me understand bool type, while loops, and if statements 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_ProfessorRating
{
    class Program
    {   //Main Method
        static void Main(string[] args)
        {
            //Bool type 
            bool colorChange = false;
            while (true)
            {
                //Implementation of ProfessorRating Class
                ProfessorRating newProf = new ProfessorRating("Patrick", "Collins", "USI");

                //Implementation of ProfessorRating Class using other Constructor 
                ProfessorRating newProf2 = new ProfessorRating("Bob", "Smith", "Unversity of Southern Indiana", 1, 2);

                if (colorChange == false)
                {
                    //Display Method for newProf
                    newProf.displayInfo();

                    //Display Method for newProf2
                    newProf2.displayInfo();

                    //ToString Method example
                    Console.WriteLine(newProf);

                    //Makes Color Change Noticeable
                    System.Threading.Thread.Sleep(1000);

                    //Clears Console
                    Console.Clear();

                    colorChange = true;
                }

                if (colorChange == true)
                {
                    //Display Method for newProf
                    newProf.displayInfoRed();

                    //Display Method for newProf2
                    newProf2.displayInfoRed();

                    //ToString Method example
                    Console.WriteLine(newProf);

                    //Makes Color Change Noticeable
                    System.Threading.Thread.Sleep(1000);

                    //Clears Console
                    Console.Clear();

                    colorChange = false;
                }

            }
        }
    }



    //Professor Rating Class
    class ProfessorRating
    {
        //Protected Data Memebers
        private string firstName = "";
        private string lastName = "";
        private string unversity;
        private int easinessGrade;
        private int helpfulnessGrade;

        //First Constructor 
        public ProfessorRating(string fname, string lname, string uni)
        {
            firstName = fname;
            lastName = lname;
            unversity = uni;
            easinessGrade = 3;
            helpfulnessGrade = 3;
        }

        //Second Constructor
        public ProfessorRating(string fname, string lname, string uni, int egrade, int hgrade)
        {
            firstName = fname;
            lastName = lname;
            unversity = uni;
            easinessGrade = egrade;
            helpfulnessGrade = hgrade;
        }

        //University Property with Mutator and Accessor
        public string University
        {
            get
            {
                return unversity;
            }
            set
            {
                unversity = value;
            }
        }

        //First Name Property with only an Accessor
        public string getFirstName
        {
            get
            {
                return firstName;
            }
        }

        //Last Name Property with only an Accessor
        public string getLastName
        {
            get
            {
                return lastName;
            }
        }

        //Easiness Grade Method with Accessor
        public int getEGrade()
        {
            return easinessGrade;
        }

        //Easiness Grade Method with Mutator
        public void setEGrade(int grade)
        {
            easinessGrade = grade;
        }

        //Helpfulness Grade Method with Accessor
        public int getHGrade()
        {
            return helpfulnessGrade;
        }

        //Helpfulness Grade Method with Mutator
        public void setHGrade(int grade)
        {
            helpfulnessGrade = grade;
        }

        //Display Method with Proper Formatting
        public void displayInfo()
        {
            int iEGrade = getEGrade();
            string sEGrade = iEGrade.ToString();
            int iHgrade = getHGrade();
            string sHGrade = iHgrade.ToString();
            colorText("\nFirst Name: \t\t", getFirstName);
            colorText("\nLast Name: \t\t", getLastName);
            colorText("\nEasiness Grade: \t", sEGrade);
            colorText("\nHelpfulness Grade: \t", sHGrade + "\n");
        }
        //Display Method with Proper Formatting
        public void displayInfoRed()
        {
            int iEGrade = getEGrade();
            string sEGrade = iEGrade.ToString();
            int iHgrade = getHGrade();
            string sHGrade = iHgrade.ToString();
            colorTextRed("\nFirst Name: \t\t", getFirstName);
            colorTextRed("\nLast Name: \t\t", getLastName);
            colorTextRed("\nEasiness Grade: \t", sEGrade);
            colorTextRed("\nHelpfulness Grade: \t", sHGrade + "\n");
        }

        //Changes Answers into Green Text
        static void colorText(string start, string answer)
        {
            Console.Write(start);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(answer);
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        //Changes Answers into Red Text
        static void colorTextRed(string start, string answer)
        {
            Console.Write(start);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(answer);
            Console.ForegroundColor = ConsoleColor.Gray;
        }


        //ToString Override Method
        public override string ToString()
        {
            return "\nMy First Name is \t" + firstName +
                "\nMy last name is: \t" + lastName +
                "\nExample of ToString Method";
        }
    }
}

