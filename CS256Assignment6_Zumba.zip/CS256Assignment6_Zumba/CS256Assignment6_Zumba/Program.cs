﻿/*
 Programmer:    Patrick Collins
 Date:          11/7/2018
 Description:   Zumba Class 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS256Assignment6_Zumba
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = true;
            do
            {
                Zumba person = new Zumba();
                person.getName();
                person.Quest();
                exit = person.Exit();

            } while (exit);

        }
    }
}
