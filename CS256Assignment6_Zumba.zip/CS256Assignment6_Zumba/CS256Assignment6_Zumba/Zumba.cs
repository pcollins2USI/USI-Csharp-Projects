﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS256Assignment6_Zumba
{
    class Zumba
    {
        //Data Memebers
        public string Name { get; set; }
        public string[] TimeSlot = { "1:00", "3:00", "5:00", "7:00" };
        public string[] DayOfWeek = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
        public int[] AttendTimeSlot = new int[4];
        public int[] AttendWeekly = new int[6];
        public int[] DailyProfit = new int[6];
        public int[] TimeSlotProfit = new int[4];
        public double ProfitTotal { get; set; }
        public int AttendTotal { get; set; }

        public int[,] ZumAtt = {  {12,10,17,22}
                                    ,{11,13,17,22}
                                    ,{12,10,22,22}
                                    ,{9,14,17,22}
                                    ,{12,10,21,12}
                                    ,{12,10,5,10} };
        //Constructors
        public Zumba()
        {

        }
        public Zumba(string name)
        {
            Name = name;
        }
        //Methods
        public void getName()
        {
            Console.Write("Please enter your name: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Name = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Gray;
        }
        //In class notes and examples
        public void ArrayTest()
        {
            int[] myArray = new int[10];
            for (int i = 0; i < 10; i++)
            {
                myArray[i] = getInt();
                Console.WriteLine("You put: " + myArray[i]);
            }
        }
        public int getInt()
        {
            int answer;
            Console.Write("Enter integer: ");
            answer = int.Parse(Console.ReadLine());
            return answer;
        }
        public void Indexof()
        {
            Console.WriteLine(Array.IndexOf(ZumAtt, 12));
            Array.Sort(ZumAtt);
        }
        //--------END----------
        public void Quest()
        {
            Console.WriteLine("\n" + Name);
            Console.Write("Do you wish to see the Zumba revenues? (y/n): ");
            string answer = Console.ReadLine();
            if (answer.ToLower() == "y")
            {
                DisplayZumba();
                Console.WriteLine("\n-----End-----");
            }
            else if (answer.ToLower() == "n")
            {
                Console.WriteLine("-----End-----");
            }
            else
            {
                Console.WriteLine("Something went wrong with your answer: {0}", answer);
            }
        }
        public bool Exit()
        {
            Console.Write("Would you like to exit the gym administrator interface? (y/n): ");
            string answer = Console.ReadLine();
            if (answer == "y")
            {
                return false;
            }
            else if (answer == "n")
            {
                return true;
            }
            else
            {
                Console.WriteLine("User Input error");
                return true;
            }

        }
        public void DisplayZumba()
        {
            //Display Time Slot
            for (int i = 0; i < TimeSlot.Length; i++)
            {
                Console.Write("\t\t{0}", TimeSlot[i]);
            }
            Console.WriteLine("");
            //Print 2-D Array
            //Get length of first D
            for (int j = 0; j < ZumAtt.GetLength(0); j++)
            {

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("{0}", DayOfWeek[j]); //Print Day of the week
                Console.ForegroundColor = ConsoleColor.Gray;
                //Get length of second D
                for (int a = 0; a < ZumAtt.GetLength(1); a++)
                {
                    AttendTimeSlot[a] += ZumAtt[j, a];
                    ProfitTotal += (4 * ZumAtt[j, a]);
                    DailyProfit[j] += (4 * ZumAtt[j, a]);
                    AttendWeekly[j] += (ZumAtt[j, a]);
                    AttendTotal += (ZumAtt[j, a]);
                    //Check if Not W,T,S print with 2 tabs
                    if (DayOfWeek[2] != DayOfWeek[j] && DayOfWeek[3] != DayOfWeek[j] && DayOfWeek[5] != DayOfWeek[j])
                    {
                        Console.Write("\t\t{0}", ZumAtt[j, a]);
                    }
                    //On W,T,S use one tab
                    else
                    {
                        //Use one tab only on the first iteration of the for loop
                        if (a == 0)
                        {
                            Console.Write("\t{0}", ZumAtt[j, a]);

                        }
                        else
                        {
                            Console.Write("\t\t{0}", ZumAtt[j, a]);

                        }
                    }
                }
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("\tAttendence Weekly: {0} \tDaily Profit: {1:C}", AttendWeekly[j], DailyProfit[j]);
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("");
            }
            TimeSlotProfit[0] += (AttendTimeSlot[0] * 4);
            TimeSlotProfit[1] += (AttendTimeSlot[1] * 4);
            TimeSlotProfit[2] += (AttendTimeSlot[2] * 4);
            TimeSlotProfit[3] += (AttendTimeSlot[3] * 4);
            Console.WriteLine("-------------------------------------Totals---------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\t\t{0}\t\t{1}\t\t{2}\t\t{3}\tAttend Total: {4}\tTotal Profit: {5:C}", AttendTimeSlot[0], AttendTimeSlot[1], AttendTimeSlot[2], AttendTimeSlot[3], AttendTotal, ProfitTotal);
            Console.WriteLine("\t\t{0:C}\t\t{1:C}\t\t{2:C}\t\t{3:C}", TimeSlotProfit[0], TimeSlotProfit[1], TimeSlotProfit[2], TimeSlotProfit[3]);

            Console.ForegroundColor = ConsoleColor.Gray;


        }
    }
}

