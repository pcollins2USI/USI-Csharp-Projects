﻿

/*Programmer: Patrick Collins
        Date: 10/2/2018
 Description: Mars wages calculator
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mars_Take_Home_Pay
{
    class Program
    {
        //Main Method
        static void Main(string[] args)
        {
            Console.Write("What is your first name: "); string firstname = Console.ReadLine();
            Console.Write("What is your last name: "); string lastname = Console.ReadLine();
            //Added the .ToLower to make the user's response to be NOT case sensitive
            Console.Write("What is your pay type: (Hourly/Monthly) "); string paytypeS = Console.ReadLine(); string paytype = paytypeS.ToLower();
            Console.Write("What is your rate: "); string rateS = Console.ReadLine(); double rate = double.Parse(rateS);
            Employees person = new Employees(firstname, lastname, paytype, rate);

            //If User chooses Hourly
            if (paytype == "hourly")
            {
                person.wages = person.calMonthlyWages(rate);
                person.printDisplay();

            }
            //If User chooses Monthly
            else if (paytype == "monthly")
            {
                person.wages = person.calMonthlyWages(rate);
                person.printDisplay();
            }
            //User Error
            else
            {
                Console.WriteLine("User Response Error"
                    + "\nFirst Name:\t{0}"
                    + "\nLast Name:\t{1}"
                    + "\nPay Type:\t{2}"
                    + "\nRate:\t\t{3}"
                    , firstname, lastname, paytype, rate);
            }
            Console.Read();
        }

    }
    class Employees
    {
        //Data Memebers
        private string firstName;
        private string lastName;
        private string payType;
        private double socialSecurity = 0.01;
        public double wages { get; set; }

        //Constructor
        public Employees(string fname, string lname, string ptype, double rate)
        {
            wages = rate;
            firstName = fname;
            lastName = lname;
            payType = ptype;

        }


        //wages is rate after calculations
        //Hourly wages method
        public double calHourlyWages(double wages)
        {
            //If hourly wages are great than 100
            if (wages >= 100.00)
            {
                wages = wages - (wages * 0.1);
            }
            //If hourly wages are between 50 to 999 and last name Constant
            else if (wages >= 50.00 && wages < 100.00 && lastName == "Constant")
            {
                wages = wages - (wages * 0.02);
            }
            else if (wages >= 50.00 && wages < 100.00 && lastName != "Constant")
            {
                wages = wages - (wages * 0.08);
            }
            else if (wages < 50.00)
            {
                wages = wages - (wages * 0.05);
            }

            // Mars Social Security
            wages = wages - (wages * socialSecurity);

            // Mars Air Tax
            wages = wages - (wages * 0.25);
            return wages;
        }
        public double calMonthlyWages(double wages)
        {
            //If Last Constant
            if (lastName == "constant")
            {
                wages = wages - 0.00;
            }
            //If Wages are great than 10,000
            else if (wages >= 10000)
            {
                wages = wages - (wages * 0.22);
            }
            //If Wages are between 5,000 to 9,999
            else if (wages >= 5000 && wages < 10000)
            {
                wages = wages - (wages * 0.18);
            }
            //If Wages are less than 4,999
            else if (wages < 5000)
            {
                wages = wages - (wages * 0.15);
            }
            // Mars Social Security
            wages = wages - (wages * socialSecurity);
            // Mars Air Tax
            wages = wages - ((wages / 1000) * 0.25);
            return wages;
        }
        //Display Method
        public void printDisplay()
        {
            Console.WriteLine("Employee Name:\t\t{0}", firstName);
            Console.WriteLine("Employee Last:\t\t{0}", lastName);
            Console.WriteLine("Employee Pay Type:\t{0}", payType);
            Console.WriteLine("Employee Rate:\t\t{0:f2}", wages);
        }


    }
}

